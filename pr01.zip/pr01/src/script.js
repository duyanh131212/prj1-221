//handle dropdown logic
$(".dropdown-menu li a").click(function () {
  $(this)
    .parents(".dropdown")
    .find(".btn")
    .html(
      $(this).text() +
        ' <span class="glyphicon glyphicon-chevron-down " style="float:right"></span>'
    );
  $(this).parents(".dropdown").find(".btn").val($(this).data("value"));
});

$("#checkout").on("input", function () {
  const checkoutDate = new Date($("#checkout")[0].value);
  const checkinDate = new Date($("#checkin")[0].value);

  $("#days")[0].value = Math.ceil(
    (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24)
  );

  $("#cost")[0].value = 150 * $("#days")[0].value * $("#adults")[0].value;
});

$("#checkin").on("input", function () {
  const checkoutDate = new Date($("#checkout")[0].value);
  const checkinDate = new Date($("#checkin")[0].value);

  $("#days")[0].value = Math.ceil(
    (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24)
  );

  $("#cost")[0].value = 150 * $("#days")[0].value * $("#adults")[0].value;
});

$("#adults").on("input", function () {
  const checkoutDate = new Date($("#checkout")[0].value);
  const checkinDate = new Date($("#checkin")[0].value);

  $("#days")[0].value = Math.ceil(
    (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24)
  );

  $("#cost")[0].value = 150 * $("#days")[0].value * $("#adults")[0].value;
});

$(function () {
  $("#submitButton").click(function () {
    isValid = true;
    // validate username
    if (!Boolean($("#username")[0].value)) {
      $("#username").css("border", "1px solid red");
      isValid = false;
      toastr.error("Username should not be empty");
    } else {
      $("#username").css("border", "1px solid black");
    }

    // validate firstname
    if (!Boolean($("#firstname")[0].value)) {
      $("#firstname").css("border", "1px solid red");
      isValid = false;
      toastr.error("First name should not be empty");
    } else {
      $("#firstname").css("border", "1px solid black");
    }

    // validate lastname
    if (!Boolean($("#lastname")[0].value)) {
      $("#lastname").css("border", "1px solid red");
      isValid = false;
      toastr.error("Last name should not be empty");
    } else {
      $("#lastname").css("border", "1px solid black");
    }

    // validate phone number
    if (!Boolean($("#phone")[0].value)) {
      $("#phone").css("border", "1px solid red");
      isValid = false;
      toastr.error("Phone number should not be empty");
    } else {
      $("#phone").css("border", "1px solid black");
    }

    // validate tax number
    if (!Boolean($("#fax")[0].value)) {
      $("#fax").css("border", "1px solid red");
      isValid = false;
      toastr.error("Fax number should not be empty");
    } else {
      $("#fax").css("border", "1px solid black");
    }

    // validate email
    if (!Boolean($("#email")[0].value)) {
      $("#email").css("border", "1px solid red");
      isValid = false;
      toastr.error("Email should not be empty");
    } else {
      $("#email").css("border", "1px solid black");
    }
    const checkoutDate = new Date($("#checkout")[0].value);
    const checkinDate = new Date($("#checkin")[0].value);

    $("#days")[0].value = Math.ceil(
      (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24)
    );

    $("#cost")[0].value = 150 * $("#days")[0].value * $("#adults")[0].value;
    // validate cost
    
    if (Boolean(isNaN($("#cost")[0].value))) {
      isValid = false;
      toastr.error("No cost was calculated");
    } else {
      if ($("#cost")[0].value < 0) {
        isValid = false;
        toastr.error("The cost is negative");
      }
    }

    if (isValid) {
      toastr.success("Form has been successfully submitted!");
    }
  });
});

$(function () {
  $("#resetButton").click(function () {
    toastr.info("Field has been successfully reset!");
  });
});
